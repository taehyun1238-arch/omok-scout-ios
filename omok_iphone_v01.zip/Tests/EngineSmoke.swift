import Foundation

func check(_ result: Bool, _ label: String) {
    if !result { fatalError("FAIL: \(label)") }
    print("OK: \(label)")
}

@main struct EngineSmoke {
    static func main() {
        let ai=RenjuEngine()
        var b=Board()
        check(b.toMove == .black,"first move black")
        check(ai.suggest(b,for:.black)?.0 == Position(x:7,y:7),"empty center")
        for x in 4..<8 { b[x,7] = .black }
        for x in 4..<8 { b[x,8] = .white }
        check(ai.isLegal(b,Position(x:8,y:7),.black),"legal exact five")
        check(ai.isWin(b.with(Position(x:8,y:7),.black),Position(x:8,y:7),.black),"black five")
        b[8,7] = .black
        check(!ai.isLegal(b,Position(x:9,y:7),.black),"black overline forbidden")
        var w=Board()
        for x in 4..<9 { w[x,7] = .white }
        check(ai.isWin(w.with(Position(x:9,y:7),.white),Position(x:9,y:7),.white),"white six wins")
        var f=Board()
        f[6,7] = .black; f[8,7] = .black
        f[7,6] = .black; f[7,8] = .black
        check(!ai.isLegal(f,Position(x:7,y:7),.black),"approx double-three forbidden")
    }
}
