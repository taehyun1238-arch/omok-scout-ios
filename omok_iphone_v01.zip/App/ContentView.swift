import SwiftUI
import PhotosUI
import ReplayKit
import UserNotifications
import Combine

struct ContentView: View {
    @State private var calibration=ScoutStore.calibration
    @State private var myStone=ScoutStore.myStone
    @State private var notifications=ScoutStore.notifications
    @State private var screenshot: UIImage?
    @State private var selection: PhotosPickerItem?
    @State private var editMode: CalibrationMode = .topLeft
    @State private var preview: ReadResult?
    @State private var lastMove: SuggestedMove? = ScoutStore.latest
    @State private var status = ScoutStore.status
    @State private var broadcast = ScoutStore.broadcastRunning
    @State private var info=""
    private let converter=ImageConverter()
    private let recognizer=BoardRecognizer()
    private let engine=RenjuEngine()
    private let poll=Timer.publish(every:1.5,on:.main,in:.common).autoconnect()

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment:.leading,spacing:18) {
                    VStack(alignment:.leading,spacing:6) {
                        Text("오목 자동 분석").font(.largeTitle.bold())
                        Text("아이폰 한 대 · 화면 방송 기반 분석 실험판")
                            .foregroundStyle(.secondary)
                    }
                    GroupBox("① 내 돌 색상") {
                        Picker("내 돌",selection:$myStone) {
                            Text("흑돌").tag(Stone.black)
                            Text("백돌").tag(Stone.white)
                        }.pickerStyle(.segmented)
                        Text("현재 버전은 상대 프로필 자동 인식을 제공하지 않습니다. 흑/백을 직접 고르세요.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    GroupBox("② 오목판 한 번 맞추기") {
                        VStack(alignment:.leading,spacing:10) {
                            Text("카카오 오목 스크린샷을 사진에 저장한 뒤 선택하세요. 상단 왼쪽·하단 오른쪽 격자 교차점과 흑/백돌 중앙을 차례대로 터치하세요.")
                                .font(.subheadline)
                            PhotosPicker(selection:$selection,matching:.images) {
                                Label("오목 화면 스크린샷 선택",systemImage:"photo.on.rectangle")
                                    .frame(maxWidth:.infinity)
                            }.buttonStyle(.borderedProminent)
                            if let screenshot {
                                Picker("선택할 위치",selection:$editMode) {
                                    ForEach(CalibrationMode.allCases,id:\.self) { mode in
                                        Text(mode.title).tag(mode)
                                    }
                                }.pickerStyle(.menu)
                                CalibrationImage(image:screenshot,mode:editMode,c:calibration) { pt in
                                    updateCalibration(pt)
                                }
                                .frame(maxWidth:.infinity)
                                HStack {
                                    settingCheck("좌상단",calibration.isCalibrated)
                                    settingCheck("흑돌",calibration.black != nil)
                                    settingCheck("백돌",calibration.white != nil)
                                }
                                HStack {
                                    Text("색상 허용 오차")
                                    Slider(value:$calibration.tolerance,in:0.10...0.45,step:0.01)
                                    Text(String(format:"%.2f",calibration.tolerance)).monospacedDigit()
                                }.font(.caption)
                                Toggle("화면이 위아래로 뒤집혀 인식되면 켜기",isOn:$calibration.invertY)
                                    .font(.caption)
                                Button("보정 저장 + 인식 테스트") { saveAndTest() }
                                    .buttonStyle(.borderedProminent)
                            }
                        }
                    }
                    if let preview {
                        GroupBox("스크린샷 인식 테스트") {
                            VStack(alignment:.leading,spacing:8) {
                                HStack {
                                    Text("흑 \(preview.board.blackCount), 백 \(preview.board.whiteCount)")
                                    Spacer()
                                    Text(preview.board.isPlausible ? "수순 개수 정상" : "인식 오류 의심")
                                        .foregroundStyle(preview.board.isPlausible ? Color.green : Color.red)
                                }.font(.subheadline)
                                OmokBoardView(board:preview.board,
                                              marker:preview.board.toMove == myStone ? engine.suggest(preview.board,for:myStone)?.0 : nil)
                                    .frame(maxWidth:330)
                                Text("실제 판과 돌 위치가 같을 때만 방송을 사용하세요. 다른 스킨이나 틀린 판은 다시 보정하세요.")
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }
                    }
                    GroupBox("③ 알림과 화면 방송") {
                        VStack(alignment:.leading,spacing:12) {
                            Toggle("추천 수 알림",isOn:$notifications)
                            Button("아이폰 알림 권한 요청") { askNotificationPermission() }
                                .buttonStyle(.bordered)
                            Divider()
                            Text("아래 방송 시작 버튼을 눌러 화면 방송을 켠 후 카카오 오목으로 이동하세요. 매 착수를 확인하고 내 차례에 알림을 요청합니다.")
                                .font(.subheadline)
                            HStack {
                                SystemBroadcastPicker().frame(width:52,height:52)
                                VStack(alignment:.leading) {
                                    Text("화면 방송 시작").font(.headline)
                                    Text("시스템 팝업에서 방송 시작 선택").font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                            }
                            Text("상태: \(status)").font(.footnote)
                                .foregroundStyle(broadcast ? Color.green : Color.secondary)
                        }
                    }
                    GroupBox("최근 추천") {
                        if let lastMove {
                            VStack(alignment:.leading,spacing:6) {
                                Text(lastMove.position.label).font(.system(size:38,weight:.bold,design:.rounded))
                                Text(lastMove.note).font(.subheadline)
                                Text("\(lastMove.scannedAt.formatted(date:.omitted,time:.standard)) · 색상 유사도 지표 \(Int(lastMove.detectionScore*100))%")
                                    .font(.caption).foregroundStyle(.secondary)
                            }.frame(maxWidth:.infinity,alignment:.leading)
                        } else { Text("아직 분석된 수가 없어요.").foregroundStyle(.secondary) }
                    }
                    Text("시험 버전: 금수 판단은 근사치, 2수 탐색은 최선 수 보장 없음. 화면 인식·알림은 iOS 기기 테스트 전이며 게임 위 화살표 오버레이는 제공되지 않습니다.")
                        .font(.footnote).foregroundStyle(.secondary)
                }.padding(16)
            }
            .navigationBarTitleDisplayMode(.inline)
            .onChange(of:selection) { _,next in
                Task {
                    if let data=try? await next?.loadTransferable(type:Data.self),let img=UIImage(data:data) {
                        let normalized=normalize(img)
                        await MainActor.run { screenshot=normalized; preview=nil; calibration=Calibration(); editMode = .topLeft }
                    }
                }
            }
            .onChange(of:myStone) { _,v in ScoutStore.myStone=v }
            .onChange(of:notifications) { _,v in ScoutStore.notifications=v }
            .onReceive(poll) { _ in
                lastMove=ScoutStore.latest
                broadcast=ScoutStore.broadcastRunning
                status=ScoutStore.status
            }
            .alert("안내",isPresented:Binding(get:{ !info.isEmpty },set:{ if !$0 { info="" } })) {
                Button("확인",role:.cancel){ info="" }
            } message: { Text(info) }
        }
    }

    private func normalize(_ image: UIImage) -> UIImage {
        let renderer=UIGraphicsImageRenderer(size:image.size)
        return renderer.image { _ in image.draw(in:CGRect(origin:.zero,size:image.size)) }
    }
    private func settingCheck(_ label:String,_ done:Bool) -> some View {
        Label(label,systemImage:done ? "checkmark.circle.fill" : "circle")
            .font(.caption).foregroundStyle(done ? Color.green : Color.secondary)
    }
    private func updateCalibration(_ pt:NormalPoint) {
        switch editMode {
        case .topLeft:
            calibration.topLeft=pt
            calibration.isCalibrated=false
            editMode = .bottomRight
        case .bottomRight:
            calibration.bottomRight=pt
            calibration.isCalibrated=true
            editMode = .black
        case .black:
            if let screenshot,let raw=converter.fromUIImage(screenshot) { calibration.black=raw.color(pt.x,pt.y) }
            editMode = .white
        case .white:
            if let screenshot,let raw=converter.fromUIImage(screenshot) { calibration.white=raw.color(pt.x,pt.y) }
        }
        preview=nil
    }
    private func saveAndTest() {
        guard let image=screenshot,let raw=converter.fromUIImage(image) else { info="스크린샷을 먼저 선택해 주세요."; return }
        guard calibration.ready else { info="격자 양 끝과 흑돌·백돌 중앙을 모두 지정해 주세요.";return }
        ScoutStore.saveCalibration(calibration)
        preview=recognizer.read(raw,calibration)
        if let p=preview, !p.board.isPlausible { info="돌 수가 규칙에 맞지 않습니다. 좌표 또는 스킨 색상을 다시 지정하세요." }
        if preview == nil { info="인식에 실패했습니다. 보정 위치를 다시 설정하세요." }
    }
    private func askNotificationPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options:[.alert,.badge,.sound]) { granted,_ in
            DispatchQueue.main.async { info=granted ? "알림이 허용되었습니다." : "아이폰 설정에서 이 앱의 알림을 허용해야 합니다." }
        }
    }
}

enum CalibrationMode: String, CaseIterable {
    case topLeft, bottomRight, black, white
    var title: String {
        switch self {
        case .topLeft:return "1. 좌상단 격자 교차점"
        case .bottomRight:return "2. 우하단 격자 교차점"
        case .black:return "3. 흑돌 중앙"
        case .white:return "4. 백돌 중앙"
        }
    }
}

struct SystemBroadcastPicker: UIViewRepresentable {
    func makeUIView(context:Context) -> RPSystemBroadcastPickerView {
        let picker=RPSystemBroadcastPickerView(frame:CGRect(x:0,y:0,width:52,height:52))
        picker.preferredExtension=(Bundle.main.bundleIdentifier ?? "com.example.OmokScout")+".Broadcast"
        picker.showsMicrophoneButton=false
        return picker
    }
    func updateUIView(_ uiView:RPSystemBroadcastPickerView,context:Context) {}
}

struct CalibrationImage: View {
    let image: UIImage
    let mode: CalibrationMode
    let c: Calibration
    let onTap: (NormalPoint)->Void
    var body: some View {
        GeometryReader { proxy in
            let actual=CGSize(width:proxy.size.width,height:proxy.size.width*image.size.height/image.size.width)
            Image(uiImage:image).resizable().frame(width:actual.width,height:actual.height)
                .overlay(alignment:.topLeading) {
                    Canvas { context,size in
                        let a=CGPoint(x:c.topLeft.x*size.width,y:c.topLeft.y*size.height)
                        let b=CGPoint(x:c.bottomRight.x*size.width,y:c.bottomRight.y*size.height)
                        var edges=Path();edges.addRect(CGRect(x:a.x,y:a.y,width:b.x-a.x,height:b.y-a.y))
                        context.stroke(edges,with:.color(.yellow),lineWidth:2)
                        for p in [a,b] {
                            let spot=Path(ellipseIn:CGRect(x:p.x-5,y:p.y-5,width:10,height:10))
                            context.fill(spot,with:.color(.red))
                        }
                    }
                }
                .contentShape(Rectangle())
                .gesture(DragGesture(minimumDistance:0).onEnded { event in
                    let x=min(1,max(0,event.location.x/actual.width))
                    let y=min(1,max(0,event.location.y/actual.height))
                    onTap(NormalPoint(x:x,y:y))
                })
        }
        .aspectRatio(image.size.width/image.size.height,contentMode:.fit)
        .clipShape(RoundedRectangle(cornerRadius:8))
    }
}

struct OmokBoardView: View {
    let board: Board
    let marker: Position?
    var body: some View {
        Canvas { context,size in
            let edge=size.width*0.06
            let span=size.width-2*edge
            let step=span/14
            let boardRect=CGRect(x:0,y:0,width:size.width,height:size.width)
            context.fill(Path(boardRect),with:.color(Color(red:0.82,green:0.66,blue:0.43)))
            for k in 0..<15 {
                var path=Path()
                let n=edge+CGFloat(k)*step
                path.move(to:CGPoint(x:edge,y:n));path.addLine(to:CGPoint(x:edge+span,y:n))
                path.move(to:CGPoint(x:n,y:edge));path.addLine(to:CGPoint(x:n,y:edge+span))
                context.stroke(path,with:.color(.black.opacity(0.5)),lineWidth:0.7)
            }
            for y in 0..<15 { for x in 0..<15 {
                let s=board[x,y]
                if s != .empty {
                    let loc=CGPoint(x:edge+CGFloat(x)*step,y:edge+CGFloat(y)*step)
                    let p=Path(ellipseIn:CGRect(x:loc.x-step*0.42,y:loc.y-step*0.42,
                                                 width:step*0.84,height:step*0.84))
                    context.fill(p,with:.color(s == .black ? .black : .white))
                    context.stroke(p,with:.color(.black.opacity(0.4)),lineWidth:0.8)
                }
            }}
            if let m=marker {
                let loc=CGPoint(x:edge+CGFloat(m.x)*step,y:edge+CGFloat(m.y)*step)
                let p=Path(ellipseIn:CGRect(x:loc.x-step*0.46,y:loc.y-step*0.46,
                                             width:step*0.92,height:step*0.92))
                context.stroke(p,with:.color(.red),lineWidth:3)
            }
        }.aspectRatio(1,contentMode:.fit)
            .clipShape(RoundedRectangle(cornerRadius:9))
    }
}
