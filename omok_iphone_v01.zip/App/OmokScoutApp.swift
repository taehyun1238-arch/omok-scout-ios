import SwiftUI

@main struct OmokScoutApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
