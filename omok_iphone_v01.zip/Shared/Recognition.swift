import Foundation
import CoreVideo
import CoreImage
import UIKit

struct RawImage {
    let width: Int
    let height: Int
    let bgra: [UInt8]

    func color(_ x: Double, _ y: Double) -> SampleColor {
        let px=max(0,min(width-1,Int(x*Double(width))))
        let py=max(0,min(height-1,Int(y*Double(height))))
        var rr=0.0,gg=0.0,bb=0.0,count=0.0
        // A small patch to avoid anti-aliased edges and grid crossings.
        for dy in -1...1 { for dx in -1...1 {
            let cx=max(0,min(width-1,px+dx)), cy=max(0,min(height-1,py+dy))
            let offset=(cy*width+cx)*4
            bb+=Double(bgra[offset]);gg+=Double(bgra[offset+1]);rr+=Double(bgra[offset+2]);count+=1
        }}
        return SampleColor(r:rr/(255*count),g:gg/(255*count),b:bb/(255*count))
    }
}

final class ImageConverter {
    private let context=CIContext(options:[.useSoftwareRenderer:false])
    private let outputWidth=450

    func fromSampleBuffer(_ pixel: CVPixelBuffer) -> RawImage? {
        let w=CVPixelBufferGetWidth(pixel),h=CVPixelBufferGetHeight(pixel)
        guard w>0,h>0 else { return nil }
        let ow=outputWidth,oh=max(1,Int(Double(h)/Double(w)*Double(ow)))
        let input=CIImage(cvPixelBuffer:pixel)
        let resized=input.transformed(by:CGAffineTransform(scaleX:CGFloat(ow)/CGFloat(w),y:CGFloat(oh)/CGFloat(h)))
        var target: CVPixelBuffer?
        let attrs: [CFString:Any] = [kCVPixelBufferCGImageCompatibilityKey:true,
                                     kCVPixelBufferCGBitmapContextCompatibilityKey:true,
                                     kCVPixelBufferIOSurfacePropertiesKey:[:]]
        guard CVPixelBufferCreate(kCFAllocatorDefault,ow,oh,kCVPixelFormatType_32BGRA,attrs as CFDictionary,&target) == kCVReturnSuccess,
              let target=target else { return nil }
        context.render(resized,to:target,bounds:CGRect(x:0,y:0,width:ow,height:oh),colorSpace:CGColorSpaceCreateDeviceRGB())
        CVPixelBufferLockBaseAddress(target,.readOnly)
        defer { CVPixelBufferUnlockBaseAddress(target,.readOnly) }
        guard let base=CVPixelBufferGetBaseAddress(target) else { return nil }
        let stride=CVPixelBufferGetBytesPerRow(target)
        var compact=[UInt8](repeating:0,count:ow*oh*4)
        compact.withUnsafeMutableBytes { dest in
            guard let dp=dest.baseAddress else { return }
            for y in 0..<oh {
                dp.advanced(by:y*ow*4).copyMemory(from:base.advanced(by:y*stride),byteCount:ow*4)
            }
        }
        return RawImage(width:ow,height:oh,bgra:compact)
    }

    func fromUIImage(_ image: UIImage) -> RawImage? {
        guard let cg=image.cgImage else { return nil }
        let w=cg.width,h=cg.height
        guard w>0,h>0 else { return nil }
        let bytesPerRow=w*4
        var data=[UInt8](repeating:0,count:bytesPerRow*h)
        let success=data.withUnsafeMutableBytes { buffer -> Bool in
            guard let c=CGContext(data:buffer.baseAddress,width:w,height:h,bitsPerComponent:8,
                                  bytesPerRow:bytesPerRow,space:CGColorSpaceCreateDeviceRGB(),
                                  bitmapInfo:CGImageAlphaInfo.premultipliedFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue) else { return false }
            c.draw(cg,in:CGRect(x:0,y:0,width:w,height:h))
            return true
        }
        guard success else { return nil }
        return RawImage(width:w,height:h,bgra:data)
    }
}

struct ReadResult {
    let board: Board
    let score: Double
    let detected: Int
}

struct BoardRecognizer {
    func read(_ image: RawImage, _ c: Calibration) -> ReadResult? {
        guard c.ready,
              c.bottomRight.x - c.topLeft.x > 0.35,
              c.bottomRight.y - c.topLeft.y > 0.2 else { return nil }
        let black=c.black!,white=c.white!
        guard black.distance(white) > 0.12 else { return nil }
        var board=Board(),score=0.0,matched=0
        for y in 0..<15 { for x in 0..<15 {
            let nx=c.topLeft.x+(c.bottomRight.x-c.topLeft.x)*Double(x)/14.0
            var ny=c.topLeft.y+(c.bottomRight.y-c.topLeft.y)*Double(y)/14.0
            if c.invertY { ny=1-ny }
            let sample=image.color(nx,ny)
            let bd=sample.distance(black),wd=sample.distance(white)
            // Only mark a stone when close to a calibrated exemplar.
            let d=min(bd,wd)
            if d < c.tolerance {
                board[x,y] = bd < wd ? .black : .white
                score += 1-min(1,d/c.tolerance)
                matched += 1
            }
        }}
        // A badly fitted profile typically matches many background intersections.
        if matched > 145 { return nil }
        return ReadResult(board:board,score:matched == 0 ? 0 : score/Double(matched),detected:matched)
    }
}
