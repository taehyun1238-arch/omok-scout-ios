import Foundation

enum Stone: Int, Codable, CaseIterable {
    case empty = 0, black = 1, white = 2
    var enemy: Stone { self == .black ? .white : .black }
    var korean: String { self == .black ? "흑" : self == .white ? "백" : "빈칸" }
}

struct Position: Hashable, Codable {
    let x: Int
    let y: Int
    var label: String { "\(String(UnicodeScalar(65 + x)!))\(y + 1)" }
}

struct Board: Codable, Equatable {
    static let size = 15
    var cells: [Stone] = Array(repeating: .empty, count: 225)
    subscript(_ x: Int, _ y: Int) -> Stone {
        get { cells[y * 15 + x] }
        set { cells[y * 15 + x] = newValue }
    }
    func contains(_ x: Int, _ y: Int) -> Bool { (0..<15).contains(x) && (0..<15).contains(y) }
    var blackCount: Int { cells.filter { $0 == .black }.count }
    var whiteCount: Int { cells.filter { $0 == .white }.count }
    var toMove: Stone? {
        if blackCount == whiteCount { return .black }
        if blackCount == whiteCount + 1 { return .white }
        return nil
    }
    var isPlausible: Bool { toMove != nil && blackCount + whiteCount <= 225 }
    var occupied: Int { blackCount + whiteCount }
    var fingerprint: String { cells.map { String($0.rawValue) }.joined() }
    func candidates(radius: Int = 2) -> [Position] {
        if occupied == 0 { return [Position(x: 7, y: 7)] }
        var points = Set<Position>()
        for y in 0..<15 { for x in 0..<15 where self[x,y] != .empty {
            for dy in -radius...radius { for dx in -radius...radius {
                let nx = x + dx, ny = y + dy
                if contains(nx,ny) && self[nx,ny] == .empty { points.insert(Position(x:nx,y:ny)) }
            }}
        }}
        return points.sorted { a,b in a.y == b.y ? a.x < b.x : a.y < b.y }
    }
    func with(_ p: Position, _ stone: Stone) -> Board {
        var b = self; b[p.x,p.y] = stone; return b
    }
}

struct SuggestedMove: Codable {
    var position: Position
    var note: String
    var value: Int
    var color: Stone
    var scannedAt: Date
    var detectionScore: Double
}

// Lightweight search. Black forbidden-move detection is approximate: full Renju
// legality requires checking recursive legal open-threes and exceptions.
struct RenjuEngine {
    private let dirs = [(1,0),(0,1),(1,1),(1,-1)]

    func lineLength(_ b: Board, _ p: Position, _ stone: Stone, _ dx: Int, _ dy: Int) -> Int {
        var count = 1
        for sign in [-1,1] {
            var x=p.x+dx*sign, y=p.y+dy*sign
            while b.contains(x,y) && b[x,y] == stone {
                count += 1; x += dx*sign; y += dy*sign
            }
        }
        return count
    }
    func isWin(_ b: Board, _ p: Position, _ stone: Stone) -> Bool {
        dirs.contains { dx,dy in
            let l=lineLength(b,p,stone,dx,dy)
            return stone == .black ? l == 5 : l >= 5
        }
    }
    func isOverline(_ b: Board, _ p: Position) -> Bool {
        dirs.contains { dx,dy in lineLength(b,p,.black,dx,dy) >= 6 }
    }

    // Each direction is counted once, avoiding counting both ends of an open four twice.
    private func nearWinningDirections(_ b: Board, _ p: Position, _ stone: Stone) -> Int {
        var n = 0
        for (dx,dy) in dirs {
            var found = false
            for step in -4...4 where step != 0 {
                let x=p.x+dx*step, y=p.y+dy*step
                if !b.contains(x,y) || b[x,y] != .empty { continue }
                let q=Position(x:x,y:y)
                let after=b.with(q,stone)
                if lineLength(after,p,stone,dx,dy) == 5 {
                    found=true; break
                }
            }
            if found { n += 1 }
        }
        return n
    }

    private func openThreeDirections(_ b: Board, _ p: Position) -> Int {
        var n=0
        for (dx,dy) in dirs {
            var found=false
            for step in -4...4 where step != 0 {
                let x=p.x+dx*step, y=p.y+dy*step
                if !b.contains(x,y) || b[x,y] != .empty { continue }
                let q=Position(x:x,y:y), next=b.with(q,.black)
                if isOverline(next,q) { continue }
                // A free three extends to a straight four with two winning ends.
                var winningEnds=0
                for end in -5...5 where end != step {
                    let ex=p.x+dx*end, ey=p.y+dy*end
                    if next.contains(ex,ey) && next[ex,ey] == .empty {
                        let move=Position(x:ex,y:ey)
                        let after=next.with(move,.black)
                        if lineLength(after,p,.black,dx,dy) == 5 { winningEnds += 1 }
                    }
                }
                if winningEnds >= 2 { found=true; break }
            }
            if found { n += 1 }
        }
        return n
    }

    func isLegal(_ b: Board, _ p: Position, _ s: Stone) -> Bool {
        guard s != .empty, b.contains(p.x,p.y), b[p.x,p.y] == .empty else { return false }
        if s == .white { return true }
        let after=b.with(p,.black)
        if isOverline(after,p) { return false }
        if isWin(after,p,.black) { return true }
        if nearWinningDirections(after,p,.black) >= 2 { return false } // approximate 4-4
        if openThreeDirections(after,p) >= 2 { return false } // approximate 3-3
        return true
    }

    func winningMoves(_ b: Board, for s: Stone) -> [Position] {
        b.candidates(radius:1).filter { p in
            isLegal(b,p,s) && isWin(b.with(p,s),p,s)
        }
    }

    private func shapeScore(_ b: Board, _ p: Position, _ s: Stone) -> Int {
        let after=b.with(p,s)
        if isWin(after,p,s) { return 1_000_000 }
        var value=0
        for (dx,dy) in dirs {
            let run=lineLength(after,p,s,dx,dy)
            var open=0
            for sign in [-1,1] {
                var x=p.x+dx*sign, y=p.y+dy*sign
                while after.contains(x,y) && after[x,y] == s {
                    x+=dx*sign; y+=dy*sign
                }
                if after.contains(x,y) && after[x,y] == .empty { open+=1 }
            }
            if run >= 5 { value += 100_000 }
            else if run == 4 { value += open == 2 ? 40_000 : open == 1 ? 10_000 : 0 }
            else if run == 3 { value += open == 2 ? 4_000 : open == 1 ? 700 : 0 }
            else if run == 2 { value += open == 2 ? 250 : open == 1 ? 50 : 0 }
            else if open == 2 { value += 10 }
        }
        let dc = abs(7-p.x)+abs(7-p.y)
        return value + max(0,25-dc)
    }

    private func ranked(_ b: Board, _ s: Stone, limit: Int) -> [(Position,Int)] {
        var scored: [(Position,Int)] = []
        for p in b.candidates() {
            guard isLegal(b,p,s) else { continue }
            let attack = shapeScore(b,p,s)
            let defense = shapeScore(b,p,s.enemy)
            scored.append((p,attack + defense * 9 / 10))
        }
        scored.sort { a,b in
            if a.1 == b.1 { return a.0.label < b.0.label }
            return a.1 > b.1
        }
        return Array(scored.prefix(limit))
    }

    func suggest(_ b: Board, for side: Stone) -> (Position,String,Int)? {
        guard side != .empty, b.isPlausible else { return nil }
        let wins=winningMoves(b,for:side)
        if let p=wins.first { return (p,"즉시 승리 수",1_000_000) }
        let threats=winningMoves(b,for:side.enemy)
        if !threats.isEmpty {
            let defending=threats.filter { isLegal(b,$0,side) }
            if let p=defending.sorted(by: { shapeScore(b,$0,side) > shapeScore(b,$1,side) }).first {
                return (p,"상대 오목 위협 차단",900_000)
            }
        }
        let options=ranked(b,side,limit:12)
        guard !options.isEmpty else { return nil }
        var best: (Position,Int)?
        for (p,score) in options {
            let next=b.with(p,side)
            let opponent=ranked(next,side.enemy,limit:8)
            let oppMax=opponent.map { $0.1 }.max() ?? 0
            let oppWins=winningMoves(next,for:side.enemy)
            let penalty=oppWins.isEmpty ? 0 : 400_000
            let value=score*2 - oppMax - penalty
            if best == nil || value > best!.1 { best=(p,value) }
        }
        guard let selected=best else { return nil }
        return (selected.0,"2수 탐색 기반 추천 (최선 보장 아님)",selected.1)
    }
}
