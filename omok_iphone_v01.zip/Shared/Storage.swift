import Foundation

// Replace this App Group in both entitlements and here before device signing.
enum ScoutStore {
    static let groupID = "group.com.example.OmokScout"
    static var defaults: UserDefaults {
        UserDefaults(suiteName: groupID) ?? .standard
    }
    static func put<T: Encodable>(_ value: T, key: String) {
        if let data = try? JSONEncoder().encode(value) {
            defaults.set(data, forKey:key)
        }
    }
    static func get<T: Decodable>(_ type: T.Type, key: String) -> T? {
        guard let data=defaults.data(forKey:key) else { return nil }
        return try? JSONDecoder().decode(T.self, from:data)
    }
    static func saveCalibration(_ c: Calibration) { put(c,key:"calibration") }
    static var calibration: Calibration { ScoutStore.get(Calibration.self,key:"calibration") ?? Calibration() }
    static var myStone: Stone {
        get { Stone(rawValue:defaults.integer(forKey:"myStone")) ?? .black }
        set { defaults.set(newValue.rawValue,forKey:"myStone") }
    }
    static var notifications: Bool {
        get { defaults.object(forKey:"notifications") == nil ? true : defaults.bool(forKey:"notifications") }
        set { defaults.set(newValue,forKey:"notifications") }
    }
    static var broadcastRunning: Bool {
        get { defaults.bool(forKey:"broadcastRunning") }
        set { defaults.set(newValue,forKey:"broadcastRunning") }
    }
    static var latest: SuggestedMove? { ScoutStore.get(SuggestedMove.self,key:"latest") }
    static func save(_ move: SuggestedMove) { put(move,key:"latest") }
    static func clearMove() { defaults.removeObject(forKey:"latest") }
    static var status: String {
        get { defaults.string(forKey:"status") ?? "준비됨" }
        set { defaults.set(newValue,forKey:"status") }
    }
}

struct NormalPoint: Codable {
    var x: Double
    var y: Double
}
struct SampleColor: Codable, Equatable {
    var r: Double
    var g: Double
    var b: Double
    func distance(_ c: SampleColor) -> Double {
        let dr=r-c.r, dg=g-c.g, db=b-c.b
        return (dr*dr + dg*dg + db*db).squareRoot()
    }
}
struct Calibration: Codable {
    var topLeft = NormalPoint(x:0.055,y:0.25)
    var bottomRight = NormalPoint(x:0.945,y:0.70)
    var black: SampleColor?
    var white: SampleColor?
    var isCalibrated = false
    var tolerance = 0.25
    // iOS screenshot coordinate orientation and broadcast image may differ; default is portrait.
    var invertY = false
    var ready: Bool { isCalibrated && black != nil && white != nil }
}
