# 오목스카우트 0.1 — iPhone-only 개발 실험판

## 현재 가능한 것

- 카카오 오목 스크린샷을 불러와서 **15×15 판의 좌상단/우하단 격자 교차점, 검은 돌과 흰 돌 중심 색상**을 설정합니다.
- 이 설정을 재사용해 ReplayKit 방송 확장 기능에서 화면을 대략 0.8초 간격으로 분석합니다.
- 돌 수가 정상이고 내 차례로 추정되면 **2수 탐색 기반 추천 좌표**를 만들고 로컬 알림을 요청합니다.
- 3-3/4-4/장목 금수 일부를 검사하고 테스트에는 통과했지만, **정식 렌주 금수 완전 구현이 아닙니다**. 최선의 수/무패도 보장하지 않습니다.
- 스크린샷을 파일이나 서버로 보내지 않으며 앱은 오프라인 계산을 수행합니다.

## 아직 제공되지 않거나 검증되지 않은 것

- **이 파일은 IPA가 아닌 소스 코드**입니다. 실제 iPhone 빌드·화면 방송 캡처·알림 동작을 검증하지 못했습니다.
- 카카오 오목의 모든 돌 스킨 자동 분류, 오른쪽 아래 아바타로 흑백 자동 판단, 게임 화면 위 직접 그리는 오버레이, 자동 착수는 없습니다.
- 시스템 알림은 집중 모드, 알림 표시 설정, 화면 방송 확장 API 동작에 따라 늦거나 나타나지 않을 수 있습니다.
- 다른 앱의 화면 캡처에 대한 사용자의 동의가 필요하며 시스템 방송 시작 버튼을 매번 누를 수 있습니다.
- iOS 26의 ReplayKit 샘플 버퍼 API는 최신 SDK에서 deprecated로 표기됩니다. iOS 27+의 ScreenCaptureKit로 추후 전환 고려.

## 아이폰 한 대로 빌드하는 순서

1. 사파리에서 [GitHub](https://github.com/)에 로그인하고 **비공개 저장소**를 만듭니다.
2. 저장소 화면의 **Add file → Upload files**에서 전달된 `OmokScout_source.zip`과 `codemagic.yaml` 두 파일을 업로드해 커밋합니다. 아이폰 사파리에서 불편하면 데스크톱 사이트 보기로 전환합니다.
3. [Codemagic](https://codemagic.io/)에 가입하고 GitHub 계정을 연결한 뒤 방금 저장소를 앱으로 추가합니다. Native iOS / `codemagic.yaml` 워크플로를 선택합니다.
4. 먼저 `01 · 컴파일 검사` 워크플로를 실행해 **코드가 컴파일되는지** 확인합니다. 서명이 없어 아이폰에 설치하는 IPA가 만들어지는 과정은 아닙니다.
5. 실제 설치는 **Apple Developer Program 유료 가입**이 필요합니다. [Apple Developer](https://developer.apple.com/programs/)에서 가입하고, 본인만의 Bundle ID를 앱과 방송 확장에 등록하고 App Group을 만듭니다. 두 App ID에 같은 App Group 기능을 켭니다.
6. `codemagic.yaml`의 `omok-signed` 하단 `APP_BUNDLE_ID`, `APP_GROUP_ID`, `ios_signing.bundle_identifier`를 본인 ID로 편집합니다. 같은 bundle ID를 App Store Connect에 앱으로 등록합니다. `codemagic`이라는 이름의 App Store Connect 연동/API 키를 Codemagic에서 설정하세요.
7. **앱 본체와 `*.Broadcast` 확장에 각각 서명 프로비저닝 프로파일이 필요**합니다. Codemagic에서 두 프로파일이 조회되고 적용되는지 확인하세요. 이후 `02 · 실기기 설치용`을 실행해서 TestFlight로 배포합니다. 서명과 App Store Connect 심사/계정 상태에 따라 추가 설정이 필요할 수 있습니다.
8. TestFlight에서 앱을 설치한 후, 아래 사용 안내를 따르세요.

> 결제하기 전에 먼저 무료 워크플로에서 컴파일되고 원하는 동작을 추가 검증하는 것이 좋습니다. 현재 파일로 바로 설치가 보장되지 않습니다.

## 설치 후 조작

1. 카카오 오목 대국 화면을 스크린샷으로 저장합니다. **흑돌·백돌이 모두 있는 화면**이어야 합니다.
2. 오목스카우트 앱에서 본인 돌 색상 흑/백을 선택합니다.
3. 스크린샷 선택 → 좌상단 **첫 번째 격자 교차점** → 우하단 **마지막 격자 교차점** → 임의의 흑돌 **정중앙** → 임의의 백돌 **정중앙** 순서로 네 번 터치합니다.
4. `보정 저장 + 인식 테스트`를 누르고, 앱이 그린 돌 위치가 실제 사진과 같은지 확인합니다. 틀리면 다시 점을 지정하고 색상 허용 오차를 조정하세요.
5. 알림을 허용한 다음 `화면 방송 시작` 버튼 → 시스템 방송 시작 → 카카오 오목 앱으로 이동합니다.
6. 내 차례가 되면 추천 좌표 알림이 표시되는지 확인합니다. 표시가 없으면 오목스카우트 앱의 상태에 문제 사유가 기록될 수 있습니다.

**판 좌표는 A1 = 왼쪽 위 교차점, O15 = 오른쪽 아래 교차점**입니다. 카카오 오목에서 좌표 축 표기 방식이 다를 수 있으므로 기보 위치를 직접 확인하세요.

## 개발자 참고

- `Shared/Board.swift`: 판 상태, 근사 금수 판정, 휴리스틱 검색
- `Shared/Recognition.swift`: 격자 교차점 색상 인식
- `Shared/Storage.swift`: 앱/확장 간 App Group 설정 공유
- `Broadcast/SampleHandler.swift`: ReplayKit 영상 프레임 처리와 알림
- `App/ContentView.swift`: 스크린샷 캘리브레이션과 방송 시작 UI
- `project.yml`: XcodeGen 프로젝트 정의
- `Tests/EngineSmoke.swift`: Linux/macOS Swift 기본 엔진 테스트 (Xcode Target에는 포함되지 않음)

로컬 테스트 명령: `swiftc Shared/Board.swift Tests/EngineSmoke.swift -o /tmp/engine-smoke && /tmp/engine-smoke`

정확한 금수와 강한 AI를 위해서는 오목 분석 엔진 강화, 스킨별 영상 캘리브레이션, 렌주 예외 규칙의 광범위한 테스트, 실제 아이폰 방송 테스트가 다음 단계입니다.
