import Foundation
import ReplayKit
import CoreMedia
import UserNotifications

// ReplayKit's sample-buffer API is deprecated in newer Apple SDKs. This target
// intentionally supports iOS 26; re-evaluate on iOS 27+ with ScreenCaptureKit.
final class SampleHandler: RPBroadcastSampleHandler {
    private let converter=ImageConverter()
    private let reader=BoardRecognizer()
    private let engine=RenjuEngine()
    private var lastProcess=Date.distantPast
    private var pendingFingerprint=""
    private var stableFrames=0
    private var lastNotified=""

    override func broadcastStarted(withSetupInfo setupInfo: [String:NSCoding & NSObjectProtocol]?) {
        ScoutStore.broadcastRunning=true
        ScoutStore.status="방송 시작됨 · 오목판 대기 중"
        ScoutStore.clearMove()
        lastNotified=""
    }

    override func broadcastFinished() {
        ScoutStore.broadcastRunning=false
        ScoutStore.status="방송 종료됨"
    }

    override func processSampleBuffer(_ sampleBuffer: CMSampleBuffer,
                                      with sampleBufferType: RPSampleBufferType) {
        guard sampleBufferType == .video else { return }
        // Analyse approximately once every 0.8 seconds; don't block the screen pipeline.
        let now=Date()
        guard now.timeIntervalSince(lastProcess)>0.8 else { return }
        lastProcess=now
        let calibration=ScoutStore.calibration
        guard calibration.ready else {
            ScoutStore.status="설정 필요 · 스크린샷에서 판 좌표·돌 색상 등록"
            return
        }
        guard let pixel=CMSampleBufferGetImageBuffer(sampleBuffer),
              let image=converter.fromSampleBuffer(pixel),
              let read=reader.read(image,calibration) else {
            ScoutStore.status="화면을 읽지 못함 · 캘리브레이션 확인"
            return
        }
        let board=read.board
        guard board.isPlausible else {
            ScoutStore.status="기보 불일치 · 돌 스킨·좌표 재설정 필요"
            return
        }
        if board.fingerprint == pendingFingerprint { stableFrames+=1 }
        else { pendingFingerprint=board.fingerprint;stableFrames=1 }
        guard stableFrames>=2 else { return }
        let color=ScoutStore.myStone
        ScoutStore.status="흑 \(board.blackCount) · 백 \(board.whiteCount) · 내 돌 \(color.korean)"
        guard board.toMove == color else { return }
        // Don't repeatedly notify for the same turn/board state.
        let token="\(color.rawValue)-\(board.fingerprint)"
        guard token != lastNotified else { return }
        // A completely empty frame could be a transition/loading screen.
        guard board.occupied>0 else { return }
        guard let (position,note,value)=engine.suggest(board,for:color) else { return }
        lastNotified=token
        let move=SuggestedMove(position:position,note:note,value:value,color:color,
                               scannedAt:now,detectionScore:read.score)
        ScoutStore.save(move)
        ScoutStore.status="추천 \(position.label) · \(note)"
        if ScoutStore.notifications { notify(move) }
    }

    private func notify(_ move: SuggestedMove) {
        let content=UNMutableNotificationContent()
        content.title="오목 추천: \(move.position.label)"
        content.body="\(move.color.korean)돌 · \(move.note) · 좌표를 직접 확인하세요"
        content.sound = .default
        content.interruptionLevel = .active
        // The system may suppress frequent local notification banners while playing.
        let req=UNNotificationRequest(identifier:UUID().uuidString,content:content,trigger:nil)
        UNUserNotificationCenter.current().add(req,withCompletionHandler:nil)
    }
}
